function removeCookie(){
    document.querySelector('#cookiePolicy').remove();
}

function changePic (element){
    element.src = "images_2/assets/succulents-2.jpg";
}